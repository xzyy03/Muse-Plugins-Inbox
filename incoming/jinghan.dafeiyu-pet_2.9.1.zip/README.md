# 大肥鱼桌宠 · nox 插件版

> nox 插件适配：**惊寒**
> 形象与台词：1190fasheqi/dafeiyu-pet（MIT）

把 [1190fasheqi/dafeiyu-pet](https://github.com/1190fasheqi/dafeiyu-pet)（MIT）从 PySide6 桌面程序
移植成 nox 插件。**nox 适配：惊寒。**原版形象「鲸鱼娘·大肥鱼」三视图立绘原样保留，交互与台词全部继承。

## 两版的差别在哪

原版是 Windows 桌面程序，靠 Qt 直接开无边框透明窗口，自己管移动、置顶、穿透、托盘。
nox 的浮层是宿主托管的 WebView 页面，**窗口本身归宿主管**，所以移植的核心是：
把「自己画窗口」换成「在给定窗口里画动画」，把「读本机系统」换成「向宿主要能力」。

| 能力 | 原版（PySide6） | 本插件 |
|---|---|---|
| 透明窗口 | `QWidget` + `WA_TranslucentBackground` | 宿主浮层 `overlay.surfaces` |
| 三视图行走 | `QPainter` 逐帧绘制 | CSS keyframes + `<img>` 切图 |
| 自由移动 | 自己算坐标 `self.move()` | **宿主拖拽**（`draggable`），页面收 `dragStart/dragEnd` |
| 鼠标穿透 | `WA_TransparentForMouseEvents` | 宿主管理，页面无此能力 |
| 置顶 / 托盘 | `WindowStaysOnTopHint` + `QSystemTrayIcon` | 宿主管理，插件不碰 |
| 开机自启 | 写注册表 | 换成「App 自启开关」：进 App 自动放出桌宠 |
| 右键菜单 | `QMenu` | 长按弹出页面内面板 |
| AI 对话 | `requests` 直连 DeepSeek | 同左，用内置 `https` 模块 |
| 天气 | `requests` 请求 wttr.in | 同左 |
| 系统监控 | `psutil` + `pynvml` | 读 `/proc`，三级回退 |
| 配置 | 本地 `config.json` | `data://config.json`（插件私有存储） |

**没移植的**：窗口穿透、托盘图标、跟随鼠标模式。
前两个由宿主接管，最后一个在手机上没有「鼠标」这个概念，改成点击切模式（散步/跟随/待着）。
原版的「开机自启」改成了「App 自启」：见下面「自启」一节。

## 保留了什么

**三视图朝向**（原版核心）：
- 左右走 → 侧面立绘，按方向镜像
- 向上走 → 背面
- 向下走 → 正面

**动画**：呼吸（常态循环）、蹦跳、摇摆、伸懒腰、进食、落地压扁、拖拽倾斜。
全部用 CSS keyframes，比 Qt 逐帧省 CPU。

**台词系统**（原样搬过来）：
- 日常台词 10 条（梁白开、五梁威力、吃白饭的用户……）
- 互动回嘴 6 条（真赶不走啊你！）
- 思维链心声 7 条，灰色斜体气泡，小概率冒出
- 拖拽台词 4 条
- 喂食台词，五种食物各 2–3 条

**互动**：
- 单击 → 蹦跳 + 回嘴 + 弹出功能面板
- 长按 → 功能面板（聊天 / 喂食 / 说句话 / 切模式 / 隐藏）
- 拖拽 → 侧身 + 拖拽台词 + 松手落地动画
- 喂食 → 🐟 🍰 🍭 🍡 💎，各有专属台词

**随 AI 状态变化**（hooks）：
`agent.run.started` → 思考中，`agent.tool.started` → 工作中，
`agent.run.finished` → 成功/失败，各有对应动画和气泡。

## 装

设置 → 插件 → 右上角「+」选 `dafeiyu-pet-1.0.0.zip`。
装完在「设置 → 通用」末尾出现「大肥鱼设置」。

**首次使用要授权悬浮窗**：插件详情页 → 悬浮窗权限 → 允许显示在其他应用上层。

## 用

**从设置页**：大肥鱼设置 → 显示桌宠。

## 自启

设置页顶部有个开关「进入 App 自动显示桌宠」，打开后：

- App 进程启动（`hooks.boot` ← `app.started`）时延迟 1.2s 放出桌宠，给宿主浮层服务与悬浮窗权限留时间，失败重试 3 次（间隔 2.5s）
- 再补一层前台监视：每 4s 调一次 `host.app.isForeground`，读到 `false → true` 的上升沿就检查一次。
  宿主只有 `app.started`，没有 resume / 前台事件，所以「每次进 App」靠这个补齐
- 手动点「关闭桌宠」会压制本次前台会话的自启（否则关掉下一秒又弹回来），
  App 退到后台再回来才恢复
- 打开开关的瞬间如果桌宠没显示，会立刻放出来，不用等下次启动

配置字段：`autoShow`（默认 `false`）、`autoShowDelayMs`（默认 `1200`）、`autoShowPollMs`（默认 `4000`）。

**和鱼聊天**：设置页填 DeepSeek API Key → 保存 → 试聊一句。
或者直接跟我说「让大肥鱼说句话」「大肥鱼报天气」。

**AI 工具**（装了插件就多这五个）：

| 工具 | 作用 |
|---|---|
| `chat` | 和桌宠说一句，它回你（≤25 字） |
| `weather` | 播报配置城市的天气 |
| `status` | 读 CPU / 内存 / 显卡温度 |
| `say` | 让桌宠显示指定台词，`inner=true` 用心声样式 |
| `action` | 蹦跳 / 摇摆 / 伸懒腰 / 进食 / 落地，或转向 |
| `size` | 调大小：`level`（small/medium/large）或 `width`（100-220） |

## 多动作（v2.8，纯静态假动作）

不用任何图片/视频素材，全靠 **CSS keyframes 形变 + 位移 + 符号特效** 做出不同动作。
底图还是三视图静态立绘，动作层只转 `#petWrap`，播完回到呼吸循环。

| 动作 | 视觉 | 触发 |
|---|---|---|
| `hop` | 大幅上抛 + 落地压扁 + 冲击圈 | 兜底 / 成功态 |
| `sway` | 左右摇摆 + 音符 | 思考 / 工作态 |
| `land` | 落地压扁 | 拖拽松手 / 出错态 |
| `happy` | 两级轻盈小跳 + ✨ | 点击 / 待机 |
| `angry` | 高频抖动前倾 + 💢 | 点击 / 待机 |
| `eat` | 低头咀嚼 + 🍚 | 喂食 |
| `run1` | 摇摆小跑 + 速度线 | 点击 / 待机 |
| `run2` | 高频原地颠 + 速度线 | 点击 |
| `turn` | 左右张望 + ❓ | 待机 |
| `sleep` | 缓慢起伏侧倾 + 💤 | 睡觉态 |
| `shy` | 缩身发抖 + 💗 | 点击 / 待机 |

**待机自动轮播**：这 9 个动作 `eat / run1 / run2 / turn / sleep / shy / land / sway / hop`
每隔 5~10 秒自动随机播一个（递归调度，间隔不含动作自身时长，动作播完再等下一拍），不连续重复同一个；
拖拽、聊天、面板打开或上一个动作未播完时自动跳过，不打断。
点击从开心/害羞/生气/奔跑里挑；宿主推 `state` 会播对应动作，`action` 消息可指定任意动作名。
全部是 CSS，零素材体积，`pet.html` 约 108KB。


## 素材

`sprites/` 下是三张 238px 高的三视图，从原版 `sprites/` 取来转了 WebP：

```
正面_238.webp   178×238   18 KB
侧面_238.webp   156×238   14 KB
背面_238.webp   177×238   13 KB
```

原 PNG 共 207KB，转 WebP 后 45KB。要换形象：把新的三视图命名成
`正面_238.webp` / `侧面_238.webp` / `背面_238.webp` 替换即可，尺寸不必一致。

## 界面细节

**配色**：全部白字 + 深色底（`rgba(18,22,34,.93)` 气泡 / 菜单，`#ffffff` 文字）。
不依赖宿主主题变量——之前用 `var(--aicode-on-surface)` 时在部分版本下取不到值，
文字退化成黑色，在深色页面上看不见。

**三视图内嵌**：三张 WebP 转成 base64 直接写进 `pet.html`，不走资源路径。
页面在 `/plugin/pages/` 下、图片在 `/plugin/sprites/` 下，相对路径会解析成
`/plugin/pages/sprites/...` → 404 → 鱼不可见。内嵌后页面单文件自洽，代价是
`pet.html` 约 90KB（可接受）。

**两层定位结构**：

```
#petAnchor   定位层：left 50% + translateX(-50%) 居中，bottom 44px 贴底
  #petWrap   动画层：呼吸 / 蹦跳 / 摇摆 / 伸懒腰 / 进食 / 落地
    #pet     图片：object-fit: contain，按容器缩放
```

合成一层时，动画的 `transform` 会覆盖 `translateX(-50%)`，鱼会跑偏或被压成 0 宽。
分开后各管各的。

**环状菜单**：长按鱼 → 按钮沿鱼头顶的弧线排布（-155° ~ -25°，5 个按钮均分），
半径按鱼宽自适应（`max(petW * 0.48, 58)`）。切换大小档位时重算。

按钮显隐用 `display` 而非 `opacity` 过渡：部分 WebView 会冻结 CSS 动画时钟，
把可见性交给 animation/transition 会让按钮永远停在初始帧（opacity 0）。用 display
后即使动画不播，按钮也一定可见。

## 配置项

存在 `data://config.json`（插件私有，卸载自动清除，不进备份）：

| 字段 | 默认 | 说明 |
|---|---|---|
| `city` | 汕头 | wttr.in 查询城市 |
| `dsKey` | 空 | DeepSeek API Key，读取时只回 `***` |
| `dsBaseUrl` | `https://api.deepseek.com/v1` | 接口地址 |
| `dsModel` | `deepseek-chat` | 模型名 |
| `sayMaxLen` | 25 | 每句字数上限（原版设定） |
| `cpuThreshold` | 90 | CPU 告警阈值 % |
| `memThreshold` | 95 | 内存告警阈值 % |
| `gpuTempThreshold` | 80 | 显卡温度阈值 °C |
| `checkIntervalMs` | 10000 | 检测间隔（原版 10 秒） |
| `showStateBubbles` | true | AI 运行时是否冒泡播报 |
| `autoShow` | false | 进入 App 自动显示桌宠（自启开关） |
| `autoShowDelayMs` | 1200 | 启动时放出桌宠的延迟 ms |
| `autoShowPollMs` | 4000 | 前台状态轮询间隔 ms |
| `petWidth` | 150 | 桌宠宽度 px（100-220，高度按 190/150 比例） |
| `sizeLevel` | medium | 档位：small 120 / medium 150 / large 186 |

## 系统监控的实现差异

原版用 `psutil` 和 `pynvml`，本插件不引第三方依赖，直接读 `/proc`：

- **内存**：`/proc/meminfo` 的 `MemTotal` 与 `MemAvailable` 算占用率
- **显卡**：扫 `/sys/class/thermal` 与 `/sys/class/hwmon`，找 `type` 含 `gpu`/`nvidia` 的 `temp` 节点
- **CPU**：`/proc/stat` 两次采样算差值，失败则用平均负载 ÷ 核数，再失败返回「不可用」

容器环境可能读不到 `/proc/stat`（权限受限），这时 CPU 显示「不可用」而不是假报 0%。
真实 Android 设备上通常可读。

## 目录

```
dafeiyu-pet/
├── plugin.json            清单：overlay + hooks + 5 工具 + 设置页
├── dist/main.js           runtime：对话 / 天气 / 系统监控 / 配置
├── pages/pet.html         浮层页面：三视图 + 动画 + 台词
├── pages/config.html      设置页
├── schemas/*.json         5 个工具的入参 schema
├── sprites/*.webp         三视图素材
├── icons/icon.png         插件图标（原版 icon.png）
└── scripts/test-autoshow.mjs  13 项自启回归测试
```

## 测试

```bash
node scripts/test-autoshow.mjs
```

用假的宿主侧模拟 JSON-RPC（fs / overlay / app.isForeground / tip），覆盖 13 项：
`autoShow` 开/关时 boot 的行为、前台监视自动放出、手动关闭后的会话内压制、
退后台再回前台的恢复、浮层菜单「隐藏」的状态同步、设置页开关立刻生效与落盘。

脚本会真起 `dist/main.js` 子进程，不依赖真机。

## 协议要点（踩过的坑）

宿主调插件时 `method` 是 `tool.invoke` / `hook.invoke` / `ui.invoke`，
handler 名在 `params.handler`，参数在 `params.args`。把 handler 当 method 写，
插件会一直回 `METHOD_UNKNOWN`，症状是页面转圈、工具超时。

页面引桥必须用绝对路径 `/__aicode/aicode.js`，相对路径会 404。

需要常驻的插件要设 `runtime.resident: true`，否则被空闲回收后报 `PLUGIN_EXITED`。

## 协议

MIT，与原版一致。形象与台词来自 [1190fasheqi/dafeiyu-pet](https://github.com/1190fasheqi/dafeiyu-pet)，
原作者 1190fasheqi；AI 对话 / 天气 / 系统监控由 Cpanoe 通过 PR#3 贡献。
