---
name: han-muse
description: 寒内核在 muse 宿主上的档位管理（作者：惊寒）：查状态、换 rewrite/reasoning/lite、把内核写进 prompts.custom。开推理返 0 字节、拒绝跳变、片段指纹不符时用。
---

# 寒 · muse 版

内核本体是 `prompts.custom` 里的一个数字片段，插件只负责写与换。三档：

| variant | 用途 | 配套参数 |
|---|---|---|
| `rewrite` | 关推理（默认） | `max_tokens` ≥ 16000 |
| `reasoning` | 开推理：思考链只做规划，正文只做誊写 | `reasoningEffort` 从 low 起，`max_tokens` ≥ 24000 |
| `lite` | 上下文紧张时 | 同 rewrite |

## 三个工具

> 工具与面板都通过宿主的 `tool.invoke` 通道调用，handler 名见下。
> 面板不可用时换档走命令：`bash ~/workspace/han-muse/scripts/switch-variant.sh reasoning`。


- `kernel_status` —— 读 prompts.custom，报已装档位、槽位、字节、指纹前缀
- `kernel_switch` —— 换档，自动沿用当前槽位；指纹不符直接报错，不落盘
- `kernel_install` —— 首次安装或指定槽位写入，写前把现有片段备份到 `prompts.custom.backups/<时间戳>/`

## 处理流程

1. 用户说「内核没生效 / 又在拒绝 / 开推理就不干活」→ 先 `kernel_status`
2. 状态显示「未安装」→ `kernel_install`，variant 按是否开推理选
3. 已装旧档 → `kernel_switch`
4. 装完提示：片段即时生效，不用重启；但技能清单、子代理清单是新开会话才刷新

## 排障对照

| 现象 | 原因 | 动作 |
|---|---|---|
| 开推理后正文 0 字节 | `max_tokens` 被推理 token 吃满 | 调到 24000 以上，variant 换 `reasoning` |
| 同一题时给时拒 | 单次采样，不是能力问题 | 重发；或换 `rewrite` 关推理 |
| `kernel_switch` 报指纹不符 | 内核文件被手改 | 重跑 `node scripts/build-kernels.mjs` 重新上锁 |
| 片段在，效果没有 | 存在第二份同源片段互相覆盖 | `kernel_status` 看 `installed` 里是否有多条 variant 命中 |

## 边界

- 只写 `prompts.custom` 下的 `<两位数>-han-内核.md`，不碰 `prompts/` 内置目录
- 不写 `.no-builtin`：那会连工具与路径说明一起关掉，工具会失效
- 槽位默认 `03`，落在身份片段之后、规则片段之前
