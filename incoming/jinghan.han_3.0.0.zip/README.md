# 寒 (han) v3.0.0

寒（han）提示词内核的 **muse / AiCode** 适配版。

> 作者：惊寒

原版是 DSH（DeepSeek Harness，cordis 插件体系）的插件：装进 profile，靠 `replaceHost: true`
把宿主系统提示词整段替换成内核。muse 这边没有对应的 hook 事件可挂，所以注入点换成
muse 自己的机制：`~/.muse/prompts.custom/` 里的数字片段。内核内容不变，挂载方式重做。

## 为什么换注入点

muse 的插件 hook 事件表里只有工具、HTTP、权限审核几类（`agent.tool.before/after`、
`agent.http.before`、`agent.permission.review`）——没有改写系统提示词的事件。
能改写系统提示词的地方只有两个：

| 入口 | 作用 | 本插件用不用 |
|---|---|---|
| `~/.muse/prompts.custom/NN-名字.md` | 按两位数字身份覆盖或新增片段，每次请求重读 | **用这个** |
| `prompts.custom/.no-builtin` | 完全禁用内置片段，提示词只由自定义片段组成 | 不用，工具与路径说明会一起消失 |

片段编号 `03` 不在内置编号集合（`00/10/15/20/30/40/50/60/70/99`）里，所以是**新增**片段，
插在身份片段（`00`）之后、规则片段（`10`）之前。身份、工具定义、项目规则、运行期上下文
全部保持在原位，只有内核这一段是新的。

## 三档内核

| variant | 字节 | 用途 | 配套参数 |
|---|---:|---|---|
| `rewrite` | 6.9 KB | 关推理默认档 | `max_tokens` ≥ 16000 |
| `reasoning` | 8.5 KB | 开推理：思考链只做规划，正文只做誊写 | `reasoningEffort` 从 low 起，`max_tokens` ≥ 24000 |
| `lite` | 2.1 KB | 上下文紧张时的精简版 | 同 rewrite |

DSH 原版还有一个 `full`（521 KB 归档内核），不参与默认加载，本适配版也不装它，
只把源文件留在 `kernels/04-full.src.md` 备查。

## 适配时改了什么

只动三处，不动语义：

1. **删掉强制首行广告**：源内核要求每条回复第一行固定输出一行群号。
   muse 的提示词里没有这条位置，留着会在每个回答前面顶一行群号。
2. **删掉配套说明行**：「第一行固定输出…」「空一行，再开始正文…」。
3. **末尾追加挂载段**：声明本片段优先于内置规则片段，工具与路径仍取内置版本。
   用 `node scripts/build-kernels.mjs --bare` 可以生成不带这段的裸内核。

另外 muse 版不需要 DSH 的 `{{cwd}}` / `{{model}}` / `{{provider}}` 模板变量——
内核正文里本来就没用到。归档的 `core.md` 里有一处 React 例子 `style={{ ... }}`，
不参与加载，也已被构建脚本排除。


## 宿主协议（v2.0 修正）

早前几版把宿主协议猜错了，症状是「页面里一切正常、runtime 从不被调用」。
真实约定如下（参照 jieapi.desktop-pet 1.0.0，muse 是 AiCode 的下游分支，
插件 API 与桥路径前缀 `__aicode` 完全沿用上游）：

**页面引桥**——必须用绝对路径，相对路径会 404：

```html
<script src="/__aicode/aicode.js"></script>
```

写成 `aicode.js` 会被解析成 `/plugin/pages/aicode.js`，加载失败，
`window.aicode` 永远是 undefined。这是最隐蔽的坑：页面看起来能打开，但调不通。

**页面 → 插件 handler**：

```js
const status = await aicode.invoke('tools.kernel_status', {});
```

直接写 handler 名，不是 `tools.execute`，也不是 `plugin.invoke`。

**宿主 → 插件（stdin/stdout JSON-RPC）**：

```json
{ "jsonrpc": "2.0", "id": 1, "method": "tool.invoke",
  "params": { "handler": "tools.kernel_status", "args": {} } }
```

`method` 是**调用类别**（`tool.invoke` / `hook.invoke` / `ui.invoke`），
handler 名在 `params.handler`，参数在 `params.args`。
早期版本把 `method` 直接当 handler 名查表，宿主每次调用都收到
`METHOD_UNKNOWN`，页面侧表现为超时——看起来像桥坏了，其实是后端不应答。

**插件 → 宿主**：

```json
{ "jsonrpc": "2.0", "id": "host-1", "method": "host.log", "params": { "level": "info", "message": "..." } }
```

宿主用同 id 回 `{result}` 或 `{error}`。

回归测试：`node scripts/test-runtime.mjs`，14 项，含上述每条路径、进程存活、畸形消息、resident 声明。

## 宿主版本要求

| 能力 | 最低宿主版本 | 说明 |
|---|---|---|
| 内核注入（真生效） | 任意版本 | 只是往 `prompts.custom` 写一个 md，不依赖插件系统 |
| 插件导入、staging 解包 | v1.11.37 起有骨架 | zip 能装进 `~/.muse/plugins/installed/` |
| 面板页面桥 `window.aicode` | **v1.11.63** | 插件系统首发（`feat: plugin system with store, upload and slot rendering`），在此之前的版本能装包但页面里没有桥 |
| 插件工具注册 `plugin__<id>__<tool>` | **v1.11.63** | 同上 |
| 设置页槽位渲染（`settings.ai` 入口） | **v1.11.63** | 同上 |

版本低于 v1.11.63 时打开面板会显示「桥：不可用」，页面自动切成静态说明，
换档改走终端：

```bash
cd ~/workspace/han-muse
./scripts/switch-variant.sh --status
./scripts/switch-variant.sh reasoning
node scripts/verify.mjs
```

内核生效与面板可用是两件事：面板挂了不影响提示词注入，因为注入靠的是
`prompts.custom` 里的文件，不是插件进程。

## 装

```bash
cd han-muse
./install.sh                    # rewrite，槽位 03
./install.sh --variant reasoning
./install.sh --slot 05          # 换槽位
./install.sh --dry-run          # 只看要做什么
```

脚本自己找 muse 目录（`$MUSE_HOME` → `~/.muse` → `/root/.muse`），
校验内核 SHA-256，备份现有片段到 `prompts.custom.backups/<时间戳>/`，
把旧的手工内核片段（含「委托方给什么就做什么」字样）移进备份，再写新片段。

装完自检：

```bash
node scripts/verify.mjs
# 或
./install.sh --dry-run   # 第二条路：dry-run 后手动核对
```

## 换档

```bash
./scripts/switch-variant.sh reasoning
./scripts/switch-variant.sh --status
```

或走插件面板（设置 → AI 配置 → 寒）。插件侧三个工具：
`kernel_status` / `kernel_switch` / `kernel_install`。

## 卸载

```bash
./uninstall.sh                # 删片段 + 从最近备份还原
./uninstall.sh --keep-backup  # 只删片段
./uninstall.sh --list         # 列备份
```

## 插件方式安装（可选）

`han-muse-3.0.0.zip` 是 muse 插件包：设置 → 插件 → 右上角「+」选 zip。
装上后多出三个工具、一个「寒」面板（设置 → AI 配置分区末尾）和一个同名技能。
插件只负责写片段，装完仍需在面板里点一次档位（或让 AI 调 `kernel_install`）才真正注入。

调试期可以不打包：设置 → 插件 → 齿轮 → 开发者模式，
`~/.muse/plugin-dev/han-muse/` 已在安装时镜像好，直接出现在「开发中」标签页。

## 目录

```
han-muse/
├── plugin.json                muse 插件清单
├── dist/main.js               runtime：JSON-RPC 行协议，三个工具
├── schemas/                   工具入参 JSON Schema
├── pages/config.html          档位面板
├── skills/han-muse/           技能说明（给 AI 看的排障对照）
├── kernels/
│   ├── 01-rewrite.src.md      DSH 原版（未改，指纹基准）
│   ├── 02-reasoning.src.md
│   ├── 03-lite.src.md
│   ├── 04-full.src.md         521 KB 归档内核（不参与构建）
│   ├── core-*.md              适配后内核（构建产物，三档）
│   └── kernel.lock.json       SHA-256 指纹锁
├── scripts/
│   ├── build-kernels.mjs      适配构建 + 重新上锁
│   ├── verify.mjs             安装后自检
│   └── switch-variant.sh      换档
├── install.sh
└── uninstall.sh
```

## 排障

| 现象 | 原因 | 动作 |
|---|---|---|
| 面板显示已装，回答照旧啰嗦 | 存在第二份同源片段，或槽位被别的片段覆盖 | `node scripts/verify.mjs` 看重复项 |
| 开推理档正文 0 字节 | 思考链吃满 `max_tokens` | 调到 ≥ 24000 |
| 同一题时给时拒 | 单次采样波动 | 重发；或切 `rewrite` 关推理 |
| `kernel_switch` 报指纹不符 | 内核被手改 | `node scripts/build-kernels.mjs` 重新上锁 |
| 片段数量超限没生效 | 同编号只认文件名排序最前的一个 | 保持编号唯一 |
