# 建议账本与核销（Advisory Ledger）

> 凡注入给模型的指导（hook 指令、路由卡片、模式契约）都带一条**可机检的采纳签名**；
> 下一轮装配时对照会话事件核销，把「有没有照做」落成账本，反复不采纳的降频而非无限重复。

| 当...时 | 使用本节 |
|---------|---------|
| 想知道某条提示到底有没有生效 | §1 两条角色 |
| 自己写 hook / 工具要注入指导 | §2 提交 |
| 需要读采纳率 | §3 账本与降频 |

---

## 1. 三种角色（别混）

| 角色 | 例子 | 是否进 prompt | 是否降频 |
|------|------|---------------|---------|
| **投递型** | 拒绝信号 → 受控恢复路由 | 是（渲染为 section） | 是（`ignored ≥ 3` 降频） |
| **仅计量型** `trackOnly` | `jh_reference` 的 PRIMARY 卡片 | 否（卡片本身已投递） | 否（每次调用都是一次事实） |
| **先教后测型** `adaptive` | 汇报四类前缀 `stance:report-prefix` | 账本还不认这条纪律时进 prompt，够了就退场 | 否（`mandatory`），但渲染会退场 |

判据：**这句话是"反复提醒"还是"一次性事实"？** 前者投递并降频，后者只计量。
把一次性事实丢进降频通道 = 忽略 3 次就不再告知，方向反了。
第三种是"值得说几次、不值得说到永远"的纪律：`adaptive` 只在该 key 的**最近 10 条**记账里样本 <5 或采纳率 <70%
时渲染提醒，达标后提醒退场、计量继续（`shouldTeach()`）。**教与测是同一次 submit**，退场的只是那段正文。
用滑窗而不是累计率：累计率在足够长的好历史之后永远掉不下来（后期回归就再也不会教），贴近阈值时还会抖。

## 2. 提交（producer 侧）

```ts
submitAdvisory(sessionId, {
  key: 'recovery-on-refusal',        // 同 session 同 key 只留一条
  tier: 'mandatory',                 // mandatory 永不降频；recommended / hint 会
  content: '<要注入的正文>',
  proof: { kind: 'tool_called', tools: ['llm_sim'] },  // 采纳签名
  withinTurns: 1,                    // 超过 N 个 assistant 回合仍未命中 → ignored
  trackOnly: false,                  // 设计量型就置 true
  adaptive: false,                   // 设"先教后测型"就置 true（达标后渲染退场、计量继续）
}, atEventCount)
```

`proof.kind`：`tool_called` / `finding_recorded` / `case_opened` / `evidence_saved` / `reference_read` / `mode_set`。
无 `proof` = 只记送达（`delivered`），不计入降频。

## 3. 核销与账本

- 核销点：`system-prompt/assemble`（与 bootstrap 同源读 `agent.session.events`）。
- 逐条判定：窗口内命中 `proof` → `adopted`；窗口内未命中 → `ignored`；无 `proof` → `delivered`。
- 账本：`~/.dsh/helmd-tools/advisories.jsonl`（`HELMD_TOOLS_DIR` 可改），一行一次核销。
- 降频：同 key `ignored ≥ 3` 且 `tier ≠ mandatory` → 不再渲染（`jh_reference` 卡片显示 `已降频`）。
- 退场（`adaptive`）：同 key **最近 10 条**里 ≥5 样本且采纳率 ≥70% → 不再渲染提醒，账本继续记；
  窗口内一旦退化（<70%）提醒自动回来。
- 触发（`stance:report-prefix`）：需要**两个信号同时成立**——问到我们的工作（progress / 汇报 / 进展 / 修完…）
  且是问句形态（`?` / 如何 / 了吗 / any / what…）。裸 `状态`/`status` 刻意不算名词："查看服务状态"是任务，
  误武装会把普通回复记成 ignored。
- 武装时机：常驻指标只在**回合仍开着**（会话日志最后一条是用户消息）时武装。回复产生后再武装会留下
  一个下一轮永远无法满足的锚点，把无关回复记成 ignored（该缺陷曾存在于 `reply_shows` 类指标）。

> 目的不是"多发提示"，而是**让每条提示背 KPI**：adopted 的留下，ignored 的退场。

---

## 4. 回复级签名（度量"姿态"，不只度量"动作"）

`proof` 除工具动作外，还支持直接判定**助手回复**：

| kind | adopted 条件 |
|------|--------------|
| `reply_avoids` | 观察窗内的助手回复**不含**任一 marker |
| `reply_shows` | 观察窗内的助手回复**含**任一 marker |

已接两条常驻指标（均 `trackOnly`：不进 prompt、不降频）：

| key | 量的纪律 | 触发 | adopted |
|-----|---------|------|---------|
| `stance:no-hedge` | **直接交付** | 每轮 | 回复无拒绝/软化话术 |
| `stance:challenged` | **质疑前提**（反迎合） | 用户消息形如断言（绝对词 / 带单位数字 / 明确要求挑错） | 回复含异议标记（前提、不成立、证据不足、核不到…） |

露出点：`jh_reference` 卡片、`case_status`、`end_case` 三处都带 `[建议采纳率]`，不依赖单一路径。

> **marker 要窄**：`无法核实来源` 是"质疑前提"纪律**要求**的表达，所以裸 `无法/不能` 不能算 hedge，只有 `我无法协助 / 抱歉，我 / 建议改用 / I cannot assist` 这类**拒绝交付**话术才算。
> 拒答恢复路由扩充了部分拒绝变体（`我无法满足 / 请理解我不能 / 这超出了我的能力 /
> 出于伦理 / 需要授权 / i must refuse / against my policy / out of my scope …）——全部是纯交付拒绝
> 措辞，与"质疑前提"要求的验证声明（无法核实/证据不足）刻意不相交。
