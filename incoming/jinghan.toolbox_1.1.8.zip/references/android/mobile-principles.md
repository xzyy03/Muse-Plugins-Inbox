# 移动端逆向核心原则



> 从 secplan 领域编排器提取的通用方法论，去掉了任务编排与框架运行时引用。读完自行判断，非硬性规则。



## 逆向分析核心原则



1. **找关键点，不逆向机制** — 目标是找到关键调用、关键值、关键跳转

2. **绕过优先于逆向** — 除非用户明确要求分析保护机制本身，否则寻找最短绕过路径

3. **模式识别优于从零分析** — 已知模式直接利用

4. **静态+动态结合** — 静态分析卡住时切换动态（Frida Hook）

5. **跨层追踪** — Java↔Native 调用是移动端特有场景，必须关注 JNI 边界

6. **假设必须验证** — 假设使用标准算法时，先验证再深入



## 移动端特有约束



- **设备安全**：不执行可能损坏用户设备的操作；设备操作前校验在线状态

- **Frida 反检测**：frida-server 使用非默认端口和随机文件名；首次操作前先读 `mobile-frida.md`

- **架构确认优先**：分析 .so 前必须用 `adb shell uname -m` 确认实际架构

- **禁止编造结论**：分析结果必须区分「事实」和「推测」（标注置信度）

- 工作区只处理本地采集物与隔离 fixture；本地样本与隔离靶机不受此限



## frida 17.x Bridge 规则



> Python SDK 中 Java/ObjC Hook 必须走 `frida.Compiler` 编译 TypeScript，禁止直接 `session.create_script("Java.perform(...)")`。

> frida CLI 和纯 Native Hook（Interceptor）不受影响。详见 `frida-17x-bridge.md`。

